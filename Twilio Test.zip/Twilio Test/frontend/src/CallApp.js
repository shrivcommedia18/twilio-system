import React, { useEffect, useRef, useState } from 'react';
import { Device } from '@twilio/voice-sdk';

function CallApp() {
  const [device, setDevice] = useState(null);
  const [connected, setConnected] = useState(false);
  const [number, setNumber] = useState('');

  useEffect(() => {
    fetch('http://localhost:3001/token?identity=user')
      .then(res => res.json())
      .then(data => {
        const dev = new Device(data.token, { debug: true });
        dev.on('connect', () => setConnected(true));
        dev.on('disconnect', () => setConnected(false));
        setDevice(dev);
      });
  }, []);

  const call = () => {
    if (device) device.connect({ To: number });
  };
  const hangup = () => {
    if (device) device.disconnectAll();
  };

  return (
    <div>
      <input value={number} onChange={e => setNumber(e.target.value)} placeholder="Enter number" />
      <button onClick={call} disabled={connected}>Call</button>
      <button onClick={hangup} disabled={!connected}>Hang Up</button>
    </div>
  );
}

export default CallApp;