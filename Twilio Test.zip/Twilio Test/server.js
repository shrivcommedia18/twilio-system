const express = require('express');
const twilio = require('twilio');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_API_KEY, TWILIO_API_SECRET } = process.env;

// Generate Access Token
app.get('/token', (req, res) => {
  const identity = req.query.identity || 'user';
  const AccessToken = twilio.jwt.AccessToken;
  const VoiceGrant = AccessToken.VoiceGrant;

  const token = new AccessToken(
    TWILIO_ACCOUNT_SID,
    TWILIO_API_KEY,
    TWILIO_API_SECRET,
    { identity }
  );
  token.addGrant(
    new VoiceGrant({
      outgoingApplicationSid: process.env.TWILIO_TWIML_APP_SID,
      incomingAllow: true
    })
  );
  res.send({ token: token.toJwt() });
});

// Handle incoming call webhook
app.post('/voice', (req, res) => {
  const twiml = new twilio.twiml.VoiceResponse();
  twiml.say('Connecting your call...');
  twiml.dial().client('user'); // Replace 'user' with dynamic identity if needed
  res.type('text/xml');
  res.send(twiml.toString());
});

app.listen(3001, () => console.log('Server running on port 3001'));